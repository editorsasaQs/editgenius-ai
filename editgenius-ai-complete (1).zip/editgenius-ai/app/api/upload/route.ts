import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file") as File;
  // Get user from session (assume auth header or cookie)
  const userId = "authenticated-user-id";  // Replace with actual session logic

  try {
    const { data, error } = await supabase.storage.from("videos").upload(`${userId}/${file.name}`, file);
    if (error) throw error;

    await supabase.from("videos").insert({
      user_id: userId,
      video_url: data.path,
      status: "uploaded",
      metadata: { name: file.name, size: file.size },
    });

    return NextResponse.json({ success: true, path: data.path });
  } catch (error) {
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}