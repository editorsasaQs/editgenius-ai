import { motion } from "framer-motion";
import Link from "next/link";
import { useSupabaseClient } from "@supabase/auth-helpers-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const supabase = useSupabaseClient();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onClose();
  };

  return (
    <motion.aside
      initial={{ x: "-100%" }}
      animate={{ x: isOpen ? 0 : "-100%" }}
      transition={{ duration: 0.3 }}
      className="fixed top-0 left-0 h-full w-64 bg-background p-4 z-50 md:relative md:w-64 md:translate-x-0"
    >
      <button className="md:hidden mb-4" onClick={onClose}>Close</button>
      <nav className="space-y-4">
        <Link href="/" className="block">Home</Link>
        <Link href="/upload" className="block">Upload</Link>
        <Link href="/pricing" className="block">Pricing</Link>
        <Link href="/dashboard" className="block">Profile</Link>  // Profile integrated in dashboard for simplicity
        <button onClick={handleLogout} className="block">Logout</button>
      </nav>
    </motion.aside>
  );
}