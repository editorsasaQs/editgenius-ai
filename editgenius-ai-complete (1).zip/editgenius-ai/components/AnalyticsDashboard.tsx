export default function AnalyticsDashboard() {
  // Placeholder: Fetch real stats from Supabase
  return (
    <div className="mt-8 p-4 bg-gray-800 rounded">
      <h2 className="text-2xl font-bold mb-4">Usage Stats</h2>
      <p>Videos processed this month: 5</p>
      <p>Total processing time: 2 hours</p>
      <p>History: [List of videos]</p>
    </div>
  );
}