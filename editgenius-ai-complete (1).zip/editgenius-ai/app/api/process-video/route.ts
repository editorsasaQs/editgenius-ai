import { NextResponse } from "next/server";
import { processVideo, generateSubtitles } from "@/lib/ffmpeg";
import { callPerplexity } from "@/lib/perplexity";

export async function POST(request: Request) {
  const { videoId, options } = await request.json();
  // Fetch video URL from DB
  const videoUrl = "fetched-video-url";  // Placeholder

  try {
    const transcript = await generateSubtitles(videoUrl);
    const analysis = await callPerplexity("Identify irrelevant scenes and key topics", transcript);
    const processed = await processVideo(videoUrl, "output.mp4", { analysis, options });
    // Upload processed video to Supabase and update DB
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Processing failed" }, { status: 500 });
  }
}