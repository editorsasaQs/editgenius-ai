"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import LoadingSpinner from "@/components/LoadingSpinner";

export default function Upload() {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [metadata, setMetadata] = useState({ duration: 0, size: 0 });
  const [previewUrl, setPreviewUrl] = useState("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPreviewUrl(URL.createObjectURL(file));
      setMetadata({ duration: 120, size: file.size });  // Replace with actual extraction using FFmpeg client-side if needed
    }
  };

  const handleUpload = async () => {
    setIsUploading(true);
    try {
      // Simulated progress (replace with actual /api/upload call)
      for (let i = 0; i <= 100; i += 10) {
        setProgress(i);
        await new Promise((res) => setTimeout(res, 500));
      }
    } catch (error) {
      alert("Upload failed. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <main className="min-h-screen p-8 bg-background">
      <h1 className="text-3xl font-bold mb-8">Upload Video</h1>
      {isUploading ? <LoadingSpinner /> : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="max-w-md mx-auto"
        >
          <input
            type="file"
            accept="video/*"
            onChange={handleFileChange}
            className="mb-4"
          />
          {previewUrl && <video src={previewUrl} className="w-full mb-4" controls />}
          <p>Duration: {metadata.duration}s | Size: { (metadata.size / 1000000).toFixed(2) } MB</p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleUpload}
            className="bg-primary text-background px-4 py-2 rounded mt-4"
          >
            Upload
          </motion.button>
          <progress value={progress} max="100" className="w-full mt-4" />
        </motion.div>
      )}
    </main>
  );
}