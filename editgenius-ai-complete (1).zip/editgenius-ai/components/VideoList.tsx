import { motion } from "framer-motion";

interface VideoListProps {
  videos: any[];
  subscription: string;
}

export default function VideoList({ videos, subscription }: VideoListProps) {
  return (
    <div className="space-y-4">
      {videos.map((video) => (
        <motion.div key={video.id} className="p-4 bg-gray-800 rounded" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <p>{video.metadata?.name || "Untitled Video"}</p>
          <button className="bg-primary text-background px-2 py-1 rounded mr-2">Edit</button>
          <button className="bg-primary text-background px-2 py-1 rounded">Download</button>
        </motion.div>
      ))}
      {subscription === "free" && videos.length >= 1 && <p className="text-red-500">Upgrade for more videos.</p>}
    </div>
  );
}