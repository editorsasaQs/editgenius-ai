export function withErrorHandling(fn: Function) {
  return async (...args: any[]) => {
    try {
      return await fn(...args);
    } catch (error) {
      console.error(error);
      throw new Error("An error occurred. Please try again.");
    }
  };
}