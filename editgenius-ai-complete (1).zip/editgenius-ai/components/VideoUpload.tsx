// Placeholder: Logic is in upload/page.tsx for simplicity. Extract if needed.
export default function VideoUpload() {
  return null;
}