const API_KEY = process.env.PERPLEXITY_API_KEY;

export async function callPerplexity(query: string, transcript: string) {
  try {
    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3-sonar-large-32k-online",
        messages: [{ role: "user", content: `${query}: ${transcript}` }],
      }),
    });
    if (!response.ok) throw new Error("Perplexity API error");
    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error(error);
    throw new Error("Failed to call Perplexity API. Please try again later.");
  }
}