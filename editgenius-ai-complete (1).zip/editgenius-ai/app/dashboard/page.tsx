"use client";

import { useEffect, useState } from "react";
import { useSupabaseClient } from "@supabase/auth-helpers-react";
import Sidebar from "@/components/Sidebar";
import VideoList from "@/components/VideoList";
import AnalyticsDashboard from "@/components/AnalyticsDashboard";
import { motion } from "framer-motion";

export default function Dashboard() {
  const supabase = useSupabaseClient();
  const [videos, setVideos] = useState([]);
  const [subscription, setSubscription] = useState("free");
  const [showSidebar, setShowSidebar] = useState(false);

  useEffect(() => {
    const fetchVideos = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase.from("videos").select("*").eq("user_id", user.id);
        setVideos(data ?? []);
      }
    };
    fetchVideos();
  }, [supabase]);

  useEffect(() => {
    const fetchSubscription = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data } = await supabase.from("users").select("subscription_plan").eq("id", user.id).single();
        setSubscription(data?.subscription_plan ?? "free");
      }
    };
    fetchSubscription();
  }, [supabase]);

  return (
    <main className="min-h-screen flex bg-background">
      <Sidebar isOpen={showSidebar} onClose={() => setShowSidebar(false)} />
      <div className="flex-1 p-8">
        <button className="md:hidden mb-4" onClick={() => setShowSidebar(true)}>Menu</button>
        <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
        <VideoList videos={videos} subscription={subscription} />
        <AnalyticsDashboard />
      </div>
    </main>
  );
}