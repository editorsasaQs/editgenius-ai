# EditGenius AI

Smart AI-powered video editing SaaS.

## Setup
1. `npm install`
2. Copy `.env.local.example` to `.env.local`
3. `npm run dev`

## Services
- Supabase: Auth, DB, Storage
- Razorpay: Payments
- Perplexity API: AI analysis
- AssemblyAI: Speech-to-text (key provided in .env)

For production, replace keys and deploy to Vercel.