"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useSupabaseClient } from "@supabase/auth-helpers-react";
import Hero from "@/components/Hero";

export default function Home() {
  const supabase = useSupabaseClient();
  const [user, setUser] = useState(null);

  supabase.auth.onAuthStateChange((event, session) => {
    setUser(session?.user ?? null);
  });

  const handleGoogleLogin = async () => {
    try {
      await supabase.auth.signInWithOAuth({ provider: "google" });
    } catch (error) {
      console.error("Login error:", error);
      alert("Failed to login with Google. Please try again.");
    }
  };

  const handleGithubLogin = async () => {
    try {
      await supabase.auth.signInWithOAuth({ provider: "github" });
    } catch (error) {
      console.error("Login error:", error);
      alert("Failed to login with GitHub. Please try again.");
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
    } catch (error) {
      console.error("Logout error:", error);
      alert("Failed to logout. Please try again.");
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-background to-primary/10">
      <Hero />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <h1 className="text-5xl font-bold mb-4">EditGenius AI</h1>
        <p className="text-xl mb-8">Create stunning videos with AI</p>
        {!user ? (
          <div className="space-x-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleGoogleLogin}
              className="bg-primary text-background px-4 py-2 rounded"
            >
              Login with Google
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleGithubLogin}
              className="bg-primary text-background px-4 py-2 rounded"
            >
              Login with GitHub
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-primary text-background px-4 py-2 rounded"
            >
              Sign Up
            </motion.button>
          </div>
        ) : (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleLogout}
            className="bg-primary text-background px-4 py-2 rounded"
          >
            Logout
          </motion.button>
        )}
      </motion.div>
    </main>
  );
}