import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { Database } from "../types/index";

export const supabase = createClientComponentClient<Database>();

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  return children;
}