export type Database = {
  public: {
    Tables: {
      users: {
        Row: { id: string; email: string; subscription_plan: string };
      };
      videos: {
        Row: { id: string; user_id: string; video_url: string; status: string; metadata: any; created_at: string };
      };
      subscriptions: {
        Row: { id: string; user_id: string; razorpay_subscription_id: string; plan: string; status: string };
      };
    };
  };
};