import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { SupabaseProvider } from "@/lib/supabase";
import { MotionConfig } from "framer-motion";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "EditGenius AI",
  description: "Smart AI-powered video editing platform",
  keywords: "AI video editor, auto-subtitles, YouTube video editor, smart video editing",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-background text-text`}>
        <SupabaseProvider>
          <MotionConfig reducedMotion="user">
            {children}
          </MotionConfig>
        </SupabaseProvider>
      </body>
    </html>
  );
}