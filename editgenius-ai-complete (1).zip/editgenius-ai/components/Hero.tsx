import { motion } from "framer-motion";

export default function Hero() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="absolute inset-0 bg-gradient-to-r from-primary to-background opacity-50"
      // Optional: Add <video autoPlay muted loop src="/background.mp4" className="object-cover w-full h-full" />
    />
  );
}