import { NextResponse } from "next/server";
import Razorpay from "razorpay";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
const razorpay = new Razorpay({
  key_id: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(request: Request) {
  const body = await request.text();
  // Verify signature (use razorpay.utils.verifyWebhookSignature)
  try {
    // Parse payload and update Supabase
    const payload = JSON.parse(body);  // Example
    await supabase.from("subscriptions").update({ status: payload.status }).eq("razorpay_subscription_id", payload.subscription_id);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Webhook failed" }, { status: 500 });
  }
}