"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import PricingCard from "@/components/PricingCard";
import LoadingSpinner from "@/components/LoadingSpinner";

export default function Pricing() {
  const [isLoading, setIsLoading] = useState(false);

  const tiers = [
    { name: "Free", price: 0, features: ["1 video/month"], buttonText: "Get Started" },
    { name: "Basic", price: 499, features: ["10 videos/month"], buttonText: "Subscribe" },
    { name: "Premium", price: 999, features: ["Unlimited videos"], buttonText: "Subscribe" },
  ];

  const handleSubscribe = async (tier: string) => {
    setIsLoading(true);
    try {
      const Razorpay = (await import("razorpay")).default;
      const razorpay = new Razorpay({
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        // Add subscription options (e.g., amount, currency)
      });
      razorpay.open({
        amount: tiers.find(t => t.name === tier)?.price * 100, // in paise
        currency: "INR",
        description: `${tier} Plan`,
      });
    } catch (error) {
      alert("Payment failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen p-8 bg-background">
      <h1 className="text-3xl font-bold mb-8 text-center">Pricing</h1>
      {isLoading ? <LoadingSpinner /> : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier) => (
            <motion.div key={tier.name} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <PricingCard {...tier} onSubscribe={() => handleSubscribe(tier.name)} />
            </motion.div>
          ))}
        </div>
      )}
    </main>
  );
}