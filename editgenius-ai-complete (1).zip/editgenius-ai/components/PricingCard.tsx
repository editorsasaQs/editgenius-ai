import { motion } from "framer-motion";

interface PricingCardProps {
  name: string;
  price: number;
  features: string[];
  buttonText: string;
  onSubscribe: () => void;
}

export default function PricingCard({ name, price, features, buttonText, onSubscribe }: PricingCardProps) {
  return (
    <div className="p-6 bg-gray-800 rounded text-center">
      <h2 className="text-2xl font-bold mb-4">{name}</h2>
      <p className="text-xl mb-4">₹{price}/month</p>
      <ul className="space-y-2 mb-6">
        {features.map((feature) => <li key={feature}>{feature}</li>)}
      </ul>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onSubscribe}
        className="bg-primary text-background px-4 py-2 rounded"
      >
        {buttonText}
      </motion.button>
    </div>
  );
}